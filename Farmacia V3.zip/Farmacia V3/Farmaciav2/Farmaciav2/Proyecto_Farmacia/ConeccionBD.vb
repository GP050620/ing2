﻿Imports System.Data.SqlClient
Module ConeccionBD

    Public CONECCION As New SqlConnection
    Public Sub Abrir_BaseDato()
        CONECCION.ConnectionString = "Server=LABC205-PC11;Database=Facturacion_Farmacia;User=sa;Password=123"
        CONECCION.Open()
    End Sub

    Public Sub Cerrar_BaseDato()
        CONECCION.Close()
    End Sub



End Module