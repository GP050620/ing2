﻿Imports System.Data.SqlClient
Module Variables
    'VARIABLES TEMPORALES PARA LAS COLUMNAS DE LOS GRIDS
    Public P01 As String
    Public P02 As String
    Public P03 As String
    Public P04 As String
    Public P05 As String
    Public P06 As String
    Public P07 As String
    Public P08 As String
    Public D01 As String
    Public D02 As String
    Public D03 As String
    Public T01 As String
    Public T02 As String
    Public T03 As String
    Public T04 As String
    Public V01 As Integer
    Public V02 As String
    Public V03 As String
    Public V04 As String
    Public V05 As Integer
    Public V06 As String
    Public V07 As Integer
    Public V08 As String
    Public V09 As String
    Public V10 As String
    Public V11 As Integer
    Public V12 As String
    Public V13 As String
    Public V14 As String
    'DATA ADATPTER
    Public DA_x As SqlDataAdapter
    'VENTANAS
    Public CANCELAR_A_E As Boolean
    Public CADENA_SQL As String
    Public VPRECIO As Integer
    Public VIVA As Integer
    Public VTOTAL As Integer
End Module