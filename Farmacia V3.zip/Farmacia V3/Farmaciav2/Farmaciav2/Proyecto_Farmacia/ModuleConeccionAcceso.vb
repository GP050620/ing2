﻿Module ModuleConexionAcceso
    Public oConexion As String = "Server=LABC205-PC11;Database=Facturacion_Farmacia;User=sa;Password=123"
End Module