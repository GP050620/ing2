﻿Module ModuleConexionAcceso
    Public oConexion As String = "Data Source=DESKTOP-BI8ULFO;Initial Catalog=Facturacion_Farmacia;Integrated Security=True"
End Module