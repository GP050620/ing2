﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEditarCatTipoVenta
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        txtID = New TextBox()
        btnCancelar = New Button()
        btnAceptar = New Button()
        Label2 = New Label()
        txtDescripcion = New TextBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(115, 18)
        Label1.Name = "Label1"
        Label1.Size = New Size(163, 30)
        Label1.TabIndex = 17
        Label1.Text = "ID de Categoria"
        ' 
        ' txtID
        ' 
        txtID.Enabled = False
        txtID.Location = New Point(303, 18)
        txtID.Name = "txtID"
        txtID.ReadOnly = True
        txtID.Size = New Size(186, 23)
        txtID.TabIndex = 16
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Location = New Point(537, 173)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(75, 23)
        btnCancelar.TabIndex = 15
        btnCancelar.Text = "Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Location = New Point(39, 173)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(75, 23)
        btnAceptar.TabIndex = 14
        btnAceptar.Text = "Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(56, 87)
        Label2.Name = "Label2"
        Label2.Size = New Size(222, 30)
        Label2.TabIndex = 13
        Label2.Text = "Nombre de Categoría"
        ' 
        ' txtDescripcion
        ' 
        txtDescripcion.Location = New Point(303, 94)
        txtDescripcion.Name = "txtDescripcion"
        txtDescripcion.Size = New Size(186, 23)
        txtDescripcion.TabIndex = 12
        ' 
        ' FrmEditarCatTipoVenta
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(654, 252)
        Controls.Add(Label1)
        Controls.Add(txtID)
        Controls.Add(btnCancelar)
        Controls.Add(btnAceptar)
        Controls.Add(Label2)
        Controls.Add(txtDescripcion)
        Name = "FrmEditarCatTipoVenta"
        Text = "FrmEditarCatTipoVenta"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnAceptar As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents txtDescripcion As TextBox
End Class
