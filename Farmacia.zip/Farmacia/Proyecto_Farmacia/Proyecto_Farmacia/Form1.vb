﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.Windows.Forms
Imports Microsoft.SqlServer
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtRutaSql.Text = "Server=localhost;Database=Facturacion_Farmacia;User Id=sa;Password=123;"
    End Sub
    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        Try
            Dim connectionString As String = txtRutaSql.Text
            Using con As New SqlConnection(connectionString)
                con.Open()
                ' Consulta SQL para obtener las bases de datos.
                Dim sql As String = "SELECT name FROM sys.databases WHERE database_id > 4" ' Excluye las bases de sistema.
                Dim cmd As New SqlCommand(sql, con)
                Dim reader As SqlDataReader = cmd.ExecuteReader()
                ' Limpia el ComboBox antes de agregar las bases de datos.
                CmbBasesDatos.Items.Clear()
                ' Agrega las bases de datos al ComboBox.
                While reader.Read()
                    CmbBasesDatos.Items.Add(reader("name").ToString())
                End While
                ' Cierra el lector y la conexión.
                reader.Close()
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al buscar bases de datos: " & ex.Message,
       "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnExaminar_Click(sender As Object, e As EventArgs) Handles btnExaminar.Click

        Dim folderBrowser As New FolderBrowserDialog()
        If folderBrowser.ShowDialog() = DialogResult.OK Then
            txtRutaCopia.Text = folderBrowser.SelectedPath
        End If
    End Sub
    Private Sub btnGenerar_Click(sender As Object, e As EventArgs) Handles btnGenerar.Click

        If ValidarCampos() Then
            Try
                Dim connectionString As String = txtRutaSql.Text
                Dim selectedDatabase As String = CmbBasesDatos.Text
                Dim backupFilePath As String = txtRutaCopia.Text.TrimEnd("\"c) & "\" & selectedDatabase & ".bak"
                Using con As New SqlConnection(connectionString)
                    con.Open()
                    Dim sCmd As New StringBuilder
                    sCmd.Append("BACKUP DATABASE [" & selectedDatabase & "] TO DISK = N'" & backupFilePath & "' ")
                    sCmd.Append("WITH NOFORMAT, NOINIT, NAME = N'" & selectedDatabase & " - Copia de seguridad', SKIP, NOREWIND, NOUNLOAD, STATS = 10")
                    Dim cmd As New SqlCommand(sCmd.ToString, con)
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Copia de seguridad creada satisfactoriamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End Using
            Catch ex As Exception
                MessageBox.Show("Error al generar la copia de seguridad: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

    End Sub
    Private Function ValidarCampos() As Boolean
        If String.IsNullOrWhiteSpace(TxtRutaSql.Text) Then
            MessageBox.Show("Ingrese la cadena de conexión SQL", "Aviso",
           MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
        If String.IsNullOrWhiteSpace(CmbBasesDatos.Text) Then
            MessageBox.Show("Seleccione una Base de Datos", "Aviso",
           MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
        If String.IsNullOrWhiteSpace(txtRutaCopia.Text) Then
            MessageBox.Show("Seleccione una Ruta para la Copia de Seguridad",
           "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End If
        Return True
    End Function
End Class