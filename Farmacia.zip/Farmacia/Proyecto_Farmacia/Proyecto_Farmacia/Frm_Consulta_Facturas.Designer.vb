﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Consulta_Facturas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        GroupBox1 = New GroupBox()
        btnCancelar = New Button()
        btnBuscar = New Button()
        txtNombreCliente = New TextBox()
        DataGridView1 = New DataGridView()
        btnCerrar = New Button()
        btnReporte = New Button()
        PrintDocument1 = New Printing.PrintDocument()
        GroupBox1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(btnCancelar)
        GroupBox1.Controls.Add(btnBuscar)
        GroupBox1.Controls.Add(txtNombreCliente)
        GroupBox1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        GroupBox1.Location = New Point(12, 21)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(518, 76)
        GroupBox1.TabIndex = 0
        GroupBox1.TabStop = False
        GroupBox1.Text = "Buscar por Nombres y Apellidos de Cliente"
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Location = New Point(431, 34)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(75, 23)
        btnCancelar.TabIndex = 2
        btnCancelar.Text = "Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Location = New Point(350, 34)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(75, 23)
        btnBuscar.TabIndex = 1
        btnBuscar.Text = "Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' txtNombreCliente
        ' 
        txtNombreCliente.Location = New Point(6, 34)
        txtNombreCliente.Name = "txtNombreCliente"
        txtNombreCliente.Size = New Size(338, 23)
        txtNombreCliente.TabIndex = 0
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(12, 103)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(792, 419)
        DataGridView1.TabIndex = 1
        ' 
        ' btnCerrar
        ' 
        btnCerrar.Location = New Point(729, 55)
        btnCerrar.Name = "btnCerrar"
        btnCerrar.Size = New Size(75, 23)
        btnCerrar.TabIndex = 3
        btnCerrar.Text = "Cerrar"
        btnCerrar.UseVisualStyleBackColor = True
        ' 
        ' btnReporte
        ' 
        btnReporte.Location = New Point(598, 55)
        btnReporte.Name = "btnReporte"
        btnReporte.Size = New Size(116, 23)
        btnReporte.TabIndex = 4
        btnReporte.Text = "Generar Reporte"
        btnReporte.UseVisualStyleBackColor = True
        ' 
        ' Frm_Consulta_Facturas
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(816, 534)
        Controls.Add(btnReporte)
        Controls.Add(btnCerrar)
        Controls.Add(DataGridView1)
        Controls.Add(GroupBox1)
        Name = "Frm_Consulta_Facturas"
        Text = "Frm_Consulta_Facturas"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnBuscar As Button
    Friend WithEvents txtNombreCliente As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnCerrar As Button
    Friend WithEvents btnReporte As Button
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
End Class
