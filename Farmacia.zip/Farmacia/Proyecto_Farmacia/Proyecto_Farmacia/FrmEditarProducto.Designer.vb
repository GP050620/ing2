﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEditarProducto
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtUnidades = New TextBox()
        Label6 = New Label()
        btnCerrar = New Button()
        btnAceptar = New Button()
        txtID = New TextBox()
        Label8 = New Label()
        ChkDescontinuado = New CheckBox()
        CbCategoria = New ComboBox()
        cbProveedor = New ComboBox()
        txtPrecio = New TextBox()
        txtCantidad = New TextBox()
        txtDescripcion = New TextBox()
        Label7 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        SuspendLayout()
        ' 
        ' txtUnidades
        ' 
        txtUnidades.Location = New Point(209, 333)
        txtUnidades.Name = "txtUnidades"
        txtUnidades.Size = New Size(254, 23)
        txtUnidades.TabIndex = 38
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(100, 333)
        Label6.Margin = New Padding(5, 0, 5, 0)
        Label6.Name = "Label6"
        Label6.Size = New Size(91, 25)
        Label6.TabIndex = 37
        Label6.Text = "Unidades"
        ' 
        ' btnCerrar
        ' 
        btnCerrar.Location = New Point(369, 421)
        btnCerrar.Name = "btnCerrar"
        btnCerrar.Size = New Size(94, 33)
        btnCerrar.TabIndex = 36
        btnCerrar.Text = "Cerrar"
        btnCerrar.UseVisualStyleBackColor = True
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Location = New Point(209, 421)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(94, 33)
        btnAceptar.TabIndex = 35
        btnAceptar.Text = "Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' txtID
        ' 
        txtID.Enabled = False
        txtID.Location = New Point(209, 30)
        txtID.Name = "txtID"
        txtID.ReadOnly = True
        txtID.Size = New Size(254, 23)
        txtID.TabIndex = 34
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.Location = New Point(60, 30)
        Label8.Margin = New Padding(5, 0, 5, 0)
        Label8.Name = "Label8"
        Label8.Size = New Size(131, 25)
        Label8.TabIndex = 33
        Label8.Text = "IDPRODUCTO"
        ' 
        ' ChkDescontinuado
        ' 
        ChkDescontinuado.AutoSize = True
        ChkDescontinuado.Location = New Point(209, 391)
        ChkDescontinuado.Name = "ChkDescontinuado"
        ChkDescontinuado.Size = New Size(15, 14)
        ChkDescontinuado.TabIndex = 32
        ChkDescontinuado.UseVisualStyleBackColor = True
        ' 
        ' CbCategoria
        ' 
        CbCategoria.FormattingEnabled = True
        CbCategoria.Location = New Point(209, 125)
        CbCategoria.Name = "CbCategoria"
        CbCategoria.Size = New Size(254, 23)
        CbCategoria.TabIndex = 31
        ' 
        ' cbProveedor
        ' 
        cbProveedor.FormattingEnabled = True
        cbProveedor.Location = New Point(209, 176)
        cbProveedor.Name = "cbProveedor"
        cbProveedor.Size = New Size(254, 23)
        cbProveedor.TabIndex = 30
        ' 
        ' txtPrecio
        ' 
        txtPrecio.Location = New Point(209, 278)
        txtPrecio.Name = "txtPrecio"
        txtPrecio.Size = New Size(254, 23)
        txtPrecio.TabIndex = 29
        ' 
        ' txtCantidad
        ' 
        txtCantidad.Location = New Point(209, 223)
        txtCantidad.Name = "txtCantidad"
        txtCantidad.Size = New Size(254, 23)
        txtCantidad.TabIndex = 28
        ' 
        ' txtDescripcion
        ' 
        txtDescripcion.Location = New Point(209, 75)
        txtDescripcion.Name = "txtDescripcion"
        txtDescripcion.Size = New Size(254, 23)
        txtDescripcion.TabIndex = 27
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(52, 380)
        Label7.Margin = New Padding(5, 0, 5, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(141, 25)
        Label7.TabIndex = 26
        Label7.Text = "Descontinuado"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(52, 278)
        Label5.Margin = New Padding(5, 0, 5, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(139, 25)
        Label5.TabIndex = 25
        Label5.Text = "Precio Unitario"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(24, 223)
        Label4.Margin = New Padding(5, 0, 5, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(169, 25)
        Label4.TabIndex = 24
        Label4.Text = "Unidad de Medida"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(72, 174)
        Label3.Margin = New Padding(5, 0, 5, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(100, 25)
        Label3.TabIndex = 23
        Label3.Text = "Proveedor"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(77, 123)
        Label2.Margin = New Padding(5, 0, 5, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(95, 25)
        Label2.TabIndex = 22
        Label2.Text = "Categoria"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(60, 83)
        Label1.Margin = New Padding(5, 0, 5, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(112, 25)
        Label1.TabIndex = 21
        Label1.Text = "Descripción"
        ' 
        ' FrmEditarProducto
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(511, 500)
        Controls.Add(txtUnidades)
        Controls.Add(Label6)
        Controls.Add(btnCerrar)
        Controls.Add(btnAceptar)
        Controls.Add(txtID)
        Controls.Add(Label8)
        Controls.Add(ChkDescontinuado)
        Controls.Add(CbCategoria)
        Controls.Add(cbProveedor)
        Controls.Add(txtPrecio)
        Controls.Add(txtCantidad)
        Controls.Add(txtDescripcion)
        Controls.Add(Label7)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "FrmEditarProducto"
        Text = "FrmEditarProducto"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtUnidades As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnCerrar As Button
    Friend WithEvents btnAceptar As Button
    Friend WithEvents txtID As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ChkDescontinuado As CheckBox
    Friend WithEvents CbCategoria As ComboBox
    Friend WithEvents cbProveedor As ComboBox
    Friend WithEvents txtPrecio As TextBox
    Friend WithEvents txtCantidad As TextBox
    Friend WithEvents txtDescripcion As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
