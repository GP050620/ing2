﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtRutaSql = New TextBox()
        txtRutaCopia = New TextBox()
        CmbBasesDatos = New ComboBox()
        btnBuscar = New Button()
        btnExaminar = New Button()
        btnGenerar = New Button()
        Label1 = New Label()
        Label2 = New Label()
        SuspendLayout()
        ' 
        ' txtRutaSql
        ' 
        txtRutaSql.Location = New Point(100, 53)
        txtRutaSql.Name = "txtRutaSql"
        txtRutaSql.Size = New Size(626, 23)
        txtRutaSql.TabIndex = 0
        ' 
        ' txtRutaCopia
        ' 
        txtRutaCopia.Location = New Point(116, 105)
        txtRutaCopia.Name = "txtRutaCopia"
        txtRutaCopia.Size = New Size(332, 23)
        txtRutaCopia.TabIndex = 1
        ' 
        ' CmbBasesDatos
        ' 
        CmbBasesDatos.FormattingEnabled = True
        CmbBasesDatos.Location = New Point(576, 83)
        CmbBasesDatos.Name = "CmbBasesDatos"
        CmbBasesDatos.Size = New Size(150, 23)
        CmbBasesDatos.TabIndex = 2
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Location = New Point(474, 83)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(75, 23)
        btnBuscar.TabIndex = 3
        btnBuscar.Text = "Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' btnExaminar
        ' 
        btnExaminar.Location = New Point(373, 134)
        btnExaminar.Name = "btnExaminar"
        btnExaminar.Size = New Size(75, 23)
        btnExaminar.TabIndex = 4
        btnExaminar.Text = "Examinar"
        btnExaminar.UseVisualStyleBackColor = True
        ' 
        ' btnGenerar
        ' 
        btnGenerar.Location = New Point(651, 225)
        btnGenerar.Name = "btnGenerar"
        btnGenerar.Size = New Size(75, 23)
        btnGenerar.TabIndex = 5
        btnGenerar.Text = "Generar"
        btnGenerar.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 56)
        Label1.Name = "Label1"
        Label1.Size = New Size(82, 15)
        Label1.TabIndex = 6
        Label1.Text = "Conexión SQL"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(12, 108)
        Label2.Name = "Label2"
        Label2.Size = New Size(98, 15)
        Label2.TabIndex = 7
        Label2.Text = "Ruta de Respaldo"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(738, 260)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnGenerar)
        Controls.Add(btnExaminar)
        Controls.Add(btnBuscar)
        Controls.Add(CmbBasesDatos)
        Controls.Add(txtRutaCopia)
        Controls.Add(txtRutaSql)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtRutaSql As TextBox
    Friend WithEvents txtRutaCopia As TextBox
    Friend WithEvents CmbBasesDatos As ComboBox
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnExaminar As Button
    Friend WithEvents btnGenerar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
