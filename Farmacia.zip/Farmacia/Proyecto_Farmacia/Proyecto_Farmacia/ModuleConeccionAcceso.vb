﻿Module ModuleConexionAcceso
    Public oConexion As String = "Server=localhost;Database=Facturacion_Farmacia;User=sa;Password=123"
End Module