﻿Module ModuleConexionAcceso
    Public oConexion As String = "Server=DESKTOP-I3PK5B7;Database=Facturacion_Farmacia;User=sa;Password=123"
End Module