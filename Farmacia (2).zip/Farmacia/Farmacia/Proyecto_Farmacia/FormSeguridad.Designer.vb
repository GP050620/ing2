﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSeguridad
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtCargarUsuario = New TextBox()
        txtCargarContraseña = New TextBox()
        txtUsuario = New TextBox()
        txtContraseña = New TextBox()
        btnAceptar = New Button()
        btnCancelar = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        PictureBox1 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtCargarUsuario
        ' 
        txtCargarUsuario.Location = New Point(320, 108)
        txtCargarUsuario.Name = "txtCargarUsuario"
        txtCargarUsuario.Size = New Size(100, 23)
        txtCargarUsuario.TabIndex = 0
        ' 
        ' txtCargarContraseña
        ' 
        txtCargarContraseña.Location = New Point(320, 166)
        txtCargarContraseña.Name = "txtCargarContraseña"
        txtCargarContraseña.Size = New Size(100, 23)
        txtCargarContraseña.TabIndex = 1
        ' 
        ' txtUsuario
        ' 
        txtUsuario.Location = New Point(174, 222)
        txtUsuario.Name = "txtUsuario"
        txtUsuario.Size = New Size(246, 23)
        txtUsuario.TabIndex = 2
        ' 
        ' txtContraseña
        ' 
        txtContraseña.Location = New Point(174, 289)
        txtContraseña.Name = "txtContraseña"
        txtContraseña.Size = New Size(246, 23)
        txtContraseña.TabIndex = 3
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Location = New Point(86, 364)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(75, 23)
        btnAceptar.TabIndex = 4
        btnAceptar.Text = "Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Location = New Point(236, 364)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(75, 23)
        btnCancelar.TabIndex = 5
        btnCancelar.Text = "Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Historic", 21.75F, FontStyle.Regular, GraphicsUnit.Point)
        Label1.Location = New Point(86, 22)
        Label1.Name = "Label1"
        Label1.Size = New Size(286, 40)
        Label1.TabIndex = 6
        Label1.Text = "Validación de Acceso"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point)
        Label2.Location = New Point(53, 222)
        Label2.Name = "Label2"
        Label2.Size = New Size(77, 25)
        Label2.TabIndex = 7
        Label2.Text = "Usuario"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point)
        Label3.Location = New Point(53, 289)
        Label3.Name = "Label3"
        Label3.Size = New Size(108, 25)
        Label3.TabIndex = 8
        Label3.Text = "Contraseña"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.users_4071826_3408814_0
        PictureBox1.Location = New Point(53, 81)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(108, 108)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 9
        PictureBox1.TabStop = False
        ' 
        ' FormSeguridad
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(453, 438)
        Controls.Add(PictureBox1)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnCancelar)
        Controls.Add(btnAceptar)
        Controls.Add(txtContraseña)
        Controls.Add(txtUsuario)
        Controls.Add(txtCargarContraseña)
        Controls.Add(txtCargarUsuario)
        Name = "FormSeguridad"
        Text = "FormSeguridad"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtCargarUsuario As TextBox
    Friend WithEvents txtCargarContraseña As TextBox
    Friend WithEvents txtUsuario As TextBox
    Friend WithEvents txtContraseña As TextBox
    Friend WithEvents btnAceptar As Button
    Friend WithEvents btnCancelar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
