﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFactura
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        GroupBox1 = New GroupBox()
        txtCatTipoVenta = New TextBox()
        txtNumFactura = New TextBox()
        btnBuscarCliente = New Button()
        Label7 = New Label()
        Label6 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        txtNombreVendedor = New TextBox()
        txtNombreCliente = New TextBox()
        txtIdCliente = New TextBox()
        cmbTipoVenta = New ComboBox()
        txtHora = New TextBox()
        txtFecha = New TextBox()
        txtFacturaNo = New TextBox()
        btnSalir = New Button()
        btnGuardar = New Button()
        btnCancelar = New Button()
        btnNuevo = New Button()
        Label1 = New Label()
        GroupBox2 = New GroupBox()
        lblMontoTotal = New Label()
        lblMontoIva = New Label()
        lblMontoPrecio = New Label()
        lblTotal = New Label()
        lblIva = New Label()
        lblPrecio = New Label()
        btnEliminar = New Button()
        btnAgregar = New Button()
        DataGridView1 = New DataGridView()
        Label8 = New Label()
        btnConsulta = New Button()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(btnConsulta)
        GroupBox1.Controls.Add(txtCatTipoVenta)
        GroupBox1.Controls.Add(txtNumFactura)
        GroupBox1.Controls.Add(btnBuscarCliente)
        GroupBox1.Controls.Add(Label7)
        GroupBox1.Controls.Add(Label6)
        GroupBox1.Controls.Add(Label5)
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(txtNombreVendedor)
        GroupBox1.Controls.Add(txtNombreCliente)
        GroupBox1.Controls.Add(txtIdCliente)
        GroupBox1.Controls.Add(cmbTipoVenta)
        GroupBox1.Controls.Add(txtHora)
        GroupBox1.Controls.Add(txtFecha)
        GroupBox1.Controls.Add(txtFacturaNo)
        GroupBox1.Controls.Add(btnSalir)
        GroupBox1.Controls.Add(btnGuardar)
        GroupBox1.Controls.Add(btnCancelar)
        GroupBox1.Controls.Add(btnNuevo)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Location = New Point(12, 12)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(692, 221)
        GroupBox1.TabIndex = 0
        GroupBox1.TabStop = False
        ' 
        ' txtCatTipoVenta
        ' 
        txtCatTipoVenta.Enabled = False
        txtCatTipoVenta.Location = New Point(493, 132)
        txtCatTipoVenta.Name = "txtCatTipoVenta"
        txtCatTipoVenta.ReadOnly = True
        txtCatTipoVenta.Size = New Size(87, 23)
        txtCatTipoVenta.TabIndex = 20
        ' 
        ' txtNumFactura
        ' 
        txtNumFactura.BackColor = SystemColors.Info
        txtNumFactura.Location = New Point(6, 19)
        txtNumFactura.Name = "txtNumFactura"
        txtNumFactura.Size = New Size(165, 23)
        txtNumFactura.TabIndex = 19
        ' 
        ' btnBuscarCliente
        ' 
        btnBuscarCliente.Location = New Point(402, 190)
        btnBuscarCliente.Name = "btnBuscarCliente"
        btnBuscarCliente.Size = New Size(39, 23)
        btnBuscarCliente.TabIndex = 18
        btnBuscarCliente.Text = "..."
        btnBuscarCliente.UseVisualStyleBackColor = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(453, 168)
        Label7.Name = "Label7"
        Label7.Size = New Size(192, 15)
        Label7.TabIndex = 17
        Label7.Text = "Nombres y Apellidos del Vendedor:"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(6, 168)
        Label6.Name = "Label6"
        Label6.Size = New Size(179, 15)
        Label6.TabIndex = 16
        Label6.Text = "Nombres y Apellidos del Cliente:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(453, 114)
        Label5.Name = "Label5"
        Label5.Size = New Size(81, 15)
        Label5.TabIndex = 15
        Label5.Text = "Tipo de Venta:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(348, 114)
        Label4.Name = "Label4"
        Label4.Size = New Size(36, 15)
        Label4.TabIndex = 14
        Label4.Text = "Hora:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(177, 114)
        Label3.Name = "Label3"
        Label3.Size = New Size(41, 15)
        Label3.TabIndex = 13
        Label3.Text = "Fecha:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(6, 114)
        Label2.Name = "Label2"
        Label2.Size = New Size(68, 15)
        Label2.TabIndex = 12
        Label2.Text = "Factura No."
        ' 
        ' txtNombreVendedor
        ' 
        txtNombreVendedor.BackColor = SystemColors.Info
        txtNombreVendedor.Location = New Point(453, 190)
        txtNombreVendedor.Name = "txtNombreVendedor"
        txtNombreVendedor.Size = New Size(233, 23)
        txtNombreVendedor.TabIndex = 11
        txtNombreVendedor.Text = "----------------"
        txtNombreVendedor.TextAlign = HorizontalAlignment.Center
        ' 
        ' txtNombreCliente
        ' 
        txtNombreCliente.BackColor = SystemColors.Info
        txtNombreCliente.Location = New Point(6, 190)
        txtNombreCliente.Name = "txtNombreCliente"
        txtNombreCliente.Size = New Size(380, 23)
        txtNombreCliente.TabIndex = 10
        ' 
        ' txtIdCliente
        ' 
        txtIdCliente.Location = New Point(299, 160)
        txtIdCliente.Name = "txtIdCliente"
        txtIdCliente.Size = New Size(87, 23)
        txtIdCliente.TabIndex = 9
        ' 
        ' cmbTipoVenta
        ' 
        cmbTipoVenta.FormattingEnabled = True
        cmbTipoVenta.Location = New Point(586, 132)
        cmbTipoVenta.Name = "cmbTipoVenta"
        cmbTipoVenta.Size = New Size(98, 23)
        cmbTipoVenta.TabIndex = 8
        ' 
        ' txtHora
        ' 
        txtHora.BackColor = SystemColors.Info
        txtHora.Location = New Point(348, 132)
        txtHora.Name = "txtHora"
        txtHora.Size = New Size(99, 23)
        txtHora.TabIndex = 7
        ' 
        ' txtFecha
        ' 
        txtFecha.BackColor = SystemColors.Info
        txtFecha.Location = New Point(177, 132)
        txtFecha.Name = "txtFecha"
        txtFecha.Size = New Size(165, 23)
        txtFecha.TabIndex = 6
        ' 
        ' txtFacturaNo
        ' 
        txtFacturaNo.BackColor = SystemColors.Info
        txtFacturaNo.Location = New Point(6, 132)
        txtFacturaNo.Name = "txtFacturaNo"
        txtFacturaNo.Size = New Size(165, 23)
        txtFacturaNo.TabIndex = 5
        ' 
        ' btnSalir
        ' 
        btnSalir.Location = New Point(519, 21)
        btnSalir.Name = "btnSalir"
        btnSalir.Size = New Size(165, 39)
        btnSalir.TabIndex = 4
        btnSalir.Text = "Salir"
        btnSalir.UseVisualStyleBackColor = True
        ' 
        ' btnGuardar
        ' 
        btnGuardar.Location = New Point(348, 67)
        btnGuardar.Name = "btnGuardar"
        btnGuardar.Size = New Size(165, 39)
        btnGuardar.TabIndex = 3
        btnGuardar.Text = "Guardar"
        btnGuardar.UseVisualStyleBackColor = True
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Location = New Point(177, 67)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(165, 39)
        btnCancelar.TabIndex = 2
        btnCancelar.Text = "Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnNuevo
        ' 
        btnNuevo.Location = New Point(6, 67)
        btnNuevo.Name = "btnNuevo"
        btnNuevo.Size = New Size(165, 39)
        btnNuevo.TabIndex = 1
        btnNuevo.Text = "Nuevo"
        btnNuevo.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = SystemColors.ControlLightLight
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.ControlText
        Label1.Location = New Point(299, 19)
        Label1.Name = "Label1"
        Label1.Size = New Size(97, 32)
        Label1.TabIndex = 0
        Label1.Text = "Factura"
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(lblMontoTotal)
        GroupBox2.Controls.Add(lblMontoIva)
        GroupBox2.Controls.Add(lblMontoPrecio)
        GroupBox2.Controls.Add(lblTotal)
        GroupBox2.Controls.Add(lblIva)
        GroupBox2.Controls.Add(lblPrecio)
        GroupBox2.Controls.Add(btnEliminar)
        GroupBox2.Controls.Add(btnAgregar)
        GroupBox2.Controls.Add(DataGridView1)
        GroupBox2.Controls.Add(Label8)
        GroupBox2.Location = New Point(12, 239)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(692, 349)
        GroupBox2.TabIndex = 1
        GroupBox2.TabStop = False
        ' 
        ' lblMontoTotal
        ' 
        lblMontoTotal.AutoSize = True
        lblMontoTotal.Location = New Point(637, 322)
        lblMontoTotal.Name = "lblMontoTotal"
        lblMontoTotal.Size = New Size(13, 15)
        lblMontoTotal.TabIndex = 27
        lblMontoTotal.Text = "0"
        ' 
        ' lblMontoIva
        ' 
        lblMontoIva.AutoSize = True
        lblMontoIva.Location = New Point(637, 304)
        lblMontoIva.Name = "lblMontoIva"
        lblMontoIva.Size = New Size(13, 15)
        lblMontoIva.TabIndex = 26
        lblMontoIva.Text = "0"
        ' 
        ' lblMontoPrecio
        ' 
        lblMontoPrecio.AutoSize = True
        lblMontoPrecio.Location = New Point(637, 286)
        lblMontoPrecio.Name = "lblMontoPrecio"
        lblMontoPrecio.Size = New Size(13, 15)
        lblMontoPrecio.TabIndex = 25
        lblMontoPrecio.Text = "0"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Location = New Point(519, 322)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(39, 15)
        lblTotal.TabIndex = 24
        lblTotal.Text = "TOTAL"
        ' 
        ' lblIva
        ' 
        lblIva.AutoSize = True
        lblIva.Location = New Point(519, 304)
        lblIva.Name = "lblIva"
        lblIva.Size = New Size(24, 15)
        lblIva.TabIndex = 23
        lblIva.Text = "IVA"
        ' 
        ' lblPrecio
        ' 
        lblPrecio.AutoSize = True
        lblPrecio.Location = New Point(519, 286)
        lblPrecio.Name = "lblPrecio"
        lblPrecio.Size = New Size(47, 15)
        lblPrecio.TabIndex = 22
        lblPrecio.Text = "PRECIO"
        ' 
        ' btnEliminar
        ' 
        btnEliminar.Location = New Point(177, 304)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(165, 39)
        btnEliminar.TabIndex = 21
        btnEliminar.Text = "Eliminar"
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Location = New Point(6, 304)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(165, 39)
        btnAgregar.TabIndex = 19
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(6, 50)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(678, 216)
        DataGridView1.TabIndex = 20
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = SystemColors.ControlLightLight
        Label8.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.ForeColor = SystemColors.ControlText
        Label8.Location = New Point(299, 13)
        Label8.Name = "Label8"
        Label8.Size = New Size(131, 32)
        Label8.TabIndex = 19
        Label8.Text = "Productos"
        ' 
        ' btnConsulta
        ' 
        btnConsulta.Location = New Point(519, 67)
        btnConsulta.Name = "btnConsulta"
        btnConsulta.Size = New Size(165, 39)
        btnConsulta.TabIndex = 21
        btnConsulta.Text = "Consulta"
        btnConsulta.UseVisualStyleBackColor = True
        ' 
        ' FrmFactura
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(715, 600)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Name = "FrmFactura"
        Text = "FrmFactura"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents cmbTipoVenta As ComboBox
    Friend WithEvents txtHora As TextBox
    Friend WithEvents txtFecha As TextBox
    Friend WithEvents txtFacturaNo As TextBox
    Friend WithEvents btnSalir As Button
    Friend WithEvents btnGuardar As Button
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnNuevo As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtNombreVendedor As TextBox
    Friend WithEvents txtNombreCliente As TextBox
    Friend WithEvents txtIdCliente As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnBuscarCliente As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label8 As Label
    Friend WithEvents lblMontoTotal As Label
    Friend WithEvents lblMontoIva As Label
    Friend WithEvents lblMontoPrecio As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblIva As Label
    Friend WithEvents lblPrecio As Label
    Friend WithEvents txtNumFactura As TextBox
    Friend WithEvents txtCatTipoVenta As TextBox
    Friend WithEvents btnConsulta As Button
End Class
