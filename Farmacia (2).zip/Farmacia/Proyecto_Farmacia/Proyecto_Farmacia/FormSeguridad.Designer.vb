﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSeguridad
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        PictureBox1 = New PictureBox()
        txtCargarUsuario = New TextBox()
        txtCargarContraseña = New TextBox()
        txtContraseña = New TextBox()
        txtUsuario = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        btnAceptar = New Button()
        btnCancelar = New Button()
        Label3 = New Label()
        panelTitleBar = New Panel()
        Panel1 = New Panel()
        Label4 = New Label()
        Panel2 = New Panel()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        panelTitleBar.SuspendLayout()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.users_4071826_3408814_0
        PictureBox1.Location = New Point(147, 6)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(147, 137)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' txtCargarUsuario
        ' 
        txtCargarUsuario.Enabled = False
        txtCargarUsuario.Location = New Point(313, 19)
        txtCargarUsuario.Name = "txtCargarUsuario"
        txtCargarUsuario.ReadOnly = True
        txtCargarUsuario.Size = New Size(100, 23)
        txtCargarUsuario.TabIndex = 1
        ' 
        ' txtCargarContraseña
        ' 
        txtCargarContraseña.Enabled = False
        txtCargarContraseña.Location = New Point(312, 68)
        txtCargarContraseña.Name = "txtCargarContraseña"
        txtCargarContraseña.ReadOnly = True
        txtCargarContraseña.Size = New Size(100, 23)
        txtCargarContraseña.TabIndex = 2
        ' 
        ' txtContraseña
        ' 
        txtContraseña.Location = New Point(147, 229)
        txtContraseña.Name = "txtContraseña"
        txtContraseña.Size = New Size(137, 23)
        txtContraseña.TabIndex = 3
        ' 
        ' txtUsuario
        ' 
        txtUsuario.Location = New Point(147, 178)
        txtUsuario.Name = "txtUsuario"
        txtUsuario.Size = New Size(137, 23)
        txtUsuario.TabIndex = 4
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point)
        Label1.Location = New Point(57, 171)
        Label1.Name = "Label1"
        Label1.Size = New Size(83, 30)
        Label1.TabIndex = 5
        Label1.Text = "Usuario"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point)
        Label2.Location = New Point(22, 222)
        Label2.Name = "Label2"
        Label2.Size = New Size(118, 30)
        Label2.TabIndex = 6
        Label2.Text = "Contraseña"
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Location = New Point(48, 283)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(75, 23)
        btnAceptar.TabIndex = 7
        btnAceptar.Text = "Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Location = New Point(291, 283)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(75, 23)
        btnCancelar.TabIndex = 8
        btnCancelar.Text = "Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = Color.Transparent
        Label3.Location = New Point(80, 31)
        Label3.Name = "Label3"
        Label3.Size = New Size(333, 45)
        Label3.TabIndex = 9
        Label3.Text = "Validación de Acceso"
        ' 
        ' panelTitleBar
        ' 
        panelTitleBar.BackColor = Color.FromArgb(CByte(128), CByte(128), CByte(255))
        panelTitleBar.Controls.Add(Panel1)
        panelTitleBar.Controls.Add(Label3)
        panelTitleBar.Dock = DockStyle.Top
        panelTitleBar.Location = New Point(0, 0)
        panelTitleBar.Name = "panelTitleBar"
        panelTitleBar.Size = New Size(424, 117)
        panelTitleBar.TabIndex = 10
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(128), CByte(128), CByte(255))
        Panel1.Controls.Add(Label4)
        Panel1.Dock = DockStyle.Top
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(424, 117)
        Panel1.TabIndex = 11
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = Color.Transparent
        Label4.Location = New Point(48, 31)
        Label4.Name = "Label4"
        Label4.Size = New Size(333, 45)
        Label4.TabIndex = 9
        Label4.Text = "Validación de Acceso"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(txtContraseña)
        Panel2.Controls.Add(PictureBox1)
        Panel2.Controls.Add(txtUsuario)
        Panel2.Controls.Add(btnAceptar)
        Panel2.Controls.Add(btnCancelar)
        Panel2.Controls.Add(Label1)
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(txtCargarContraseña)
        Panel2.Controls.Add(txtCargarUsuario)
        Panel2.Controls.Add(PictureBox2)
        Panel2.Controls.Add(PictureBox3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 117)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(424, 367)
        Panel2.TabIndex = 11
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Image = My.Resources.Resources.pngtree_colorful_geometric_vector_png_image_6760069_removebg_preview_removebg_preview
        PictureBox2.Location = New Point(158, 97)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(266, 289)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 9
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Image = My.Resources.Resources.pngtree_colorful_geometric_vector_png_image_6760069_removebg_preview__1_
        PictureBox3.Location = New Point(0, 0)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(218, 219)
        PictureBox3.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox3.TabIndex = 10
        PictureBox3.TabStop = False
        ' 
        ' FormSeguridad
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(424, 484)
        Controls.Add(Panel2)
        Controls.Add(panelTitleBar)
        Name = "FormSeguridad"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Iniciar Sesión"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        panelTitleBar.ResumeLayout(False)
        panelTitleBar.PerformLayout()
        Panel1.ResumeLayout(False)
        Panel1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtCargarUsuario As TextBox
    Friend WithEvents txtCargarContraseña As TextBox
    Friend WithEvents txtContraseña As TextBox
    Friend WithEvents txtUsuario As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnAceptar As Button
    Friend WithEvents btnCancelar As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents panelTitleBar As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
End Class
