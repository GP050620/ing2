﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAgregarCategorias
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtID = New TextBox()
        txtDescripcion = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        btnAceptar = New Button()
        btnCancelar = New Button()
        Panel2 = New Panel()
        Label4 = New Label()
        Panel3 = New Panel()
        Label3 = New Label()
        Panel1 = New Panel()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' txtID
        ' 
        txtID.Enabled = False
        txtID.Location = New Point(399, 118)
        txtID.Name = "txtID"
        txtID.ReadOnly = True
        txtID.Size = New Size(186, 23)
        txtID.TabIndex = 0
        ' 
        ' txtDescripcion
        ' 
        txtDescripcion.Location = New Point(399, 188)
        txtDescripcion.Name = "txtDescripcion"
        txtDescripcion.Size = New Size(186, 23)
        txtDescripcion.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(242, 109)
        Label1.Name = "Label1"
        Label1.Size = New Size(133, 30)
        Label1.TabIndex = 2
        Label1.Text = "ID Categoria"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(152, 181)
        Label2.Name = "Label2"
        Label2.Size = New Size(223, 30)
        Label2.TabIndex = 3
        Label2.Text = "Descripción Categoria"
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Image = My.Resources.Resources.black_check_tick_icon_4_removebg_preview1
        btnAceptar.ImageAlign = ContentAlignment.MiddleLeft
        btnAceptar.Location = New Point(167, 278)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(101, 36)
        btnAceptar.TabIndex = 4
        btnAceptar.Text = "     Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Image = My.Resources.Resources.pngtree_vector_cross_icon_png_image_956622_removebg_preview
        btnCancelar.ImageAlign = ContentAlignment.MiddleLeft
        btnCancelar.Location = New Point(477, 278)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(108, 36)
        btnCancelar.TabIndex = 5
        btnCancelar.Text = "      Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.LemonChiffon
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(Panel3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(631, 100)
        Panel2.TabIndex = 24
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 36F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = Color.DimGray
        Label4.Location = New Point(177, 13)
        Label4.Name = "Label4"
        Label4.Size = New Size(430, 65)
        Label4.TabIndex = 7
        Label4.Text = "Agregar Categoria"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.PaleGoldenrod
        Panel3.Controls.Add(Label3)
        Panel3.Dock = DockStyle.Left
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(140, 100)
        Panel3.TabIndex = 5
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.ActiveCaptionText
        Label3.Location = New Point(3, 39)
        Label3.Name = "Label3"
        Label3.Size = New Size(129, 32)
        Label3.TabIndex = 17
        Label3.Text = "MED-UAM"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightGoldenrodYellow
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 100)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(140, 245)
        Panel1.TabIndex = 31
        ' 
        ' FrmAgregarCategorias
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(631, 345)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        Controls.Add(btnCancelar)
        Controls.Add(btnAceptar)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtDescripcion)
        Controls.Add(txtID)
        Name = "FrmAgregarCategorias"
        Text = "FrmAgregarCategorias"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtID As TextBox
    Friend WithEvents txtDescripcion As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnAceptar As Button
    Friend WithEvents btnCancelar As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label4 As Label
End Class
