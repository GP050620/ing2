﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEditarProducto
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtUnidades = New TextBox()
        Label6 = New Label()
        txtID = New TextBox()
        Label8 = New Label()
        ChkDescontinuado = New CheckBox()
        CbCategoria = New ComboBox()
        cbProveedor = New ComboBox()
        txtPrecio = New TextBox()
        txtCantidad = New TextBox()
        txtDescripcion = New TextBox()
        Label7 = New Label()
        Label5 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        btnCerrar = New Button()
        btnAceptar = New Button()
        Panel2 = New Panel()
        Label10 = New Label()
        Panel3 = New Panel()
        Label9 = New Label()
        Panel1 = New Panel()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' txtUnidades
        ' 
        txtUnidades.Location = New Point(379, 412)
        txtUnidades.Name = "txtUnidades"
        txtUnidades.Size = New Size(254, 23)
        txtUnidades.TabIndex = 95
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(270, 412)
        Label6.Margin = New Padding(5, 0, 5, 0)
        Label6.Name = "Label6"
        Label6.Size = New Size(91, 25)
        Label6.TabIndex = 94
        Label6.Text = "Unidades"
        ' 
        ' txtID
        ' 
        txtID.Enabled = False
        txtID.Location = New Point(379, 109)
        txtID.Name = "txtID"
        txtID.ReadOnly = True
        txtID.Size = New Size(254, 23)
        txtID.TabIndex = 93
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.Location = New Point(230, 109)
        Label8.Margin = New Padding(5, 0, 5, 0)
        Label8.Name = "Label8"
        Label8.Size = New Size(131, 25)
        Label8.TabIndex = 92
        Label8.Text = "IDPRODUCTO"
        ' 
        ' ChkDescontinuado
        ' 
        ChkDescontinuado.AutoSize = True
        ChkDescontinuado.Location = New Point(379, 470)
        ChkDescontinuado.Name = "ChkDescontinuado"
        ChkDescontinuado.Size = New Size(15, 14)
        ChkDescontinuado.TabIndex = 91
        ChkDescontinuado.UseVisualStyleBackColor = True
        ' 
        ' CbCategoria
        ' 
        CbCategoria.FormattingEnabled = True
        CbCategoria.Location = New Point(379, 204)
        CbCategoria.Name = "CbCategoria"
        CbCategoria.Size = New Size(254, 23)
        CbCategoria.TabIndex = 90
        ' 
        ' cbProveedor
        ' 
        cbProveedor.FormattingEnabled = True
        cbProveedor.Location = New Point(379, 255)
        cbProveedor.Name = "cbProveedor"
        cbProveedor.Size = New Size(254, 23)
        cbProveedor.TabIndex = 89
        ' 
        ' txtPrecio
        ' 
        txtPrecio.Location = New Point(379, 357)
        txtPrecio.Name = "txtPrecio"
        txtPrecio.Size = New Size(254, 23)
        txtPrecio.TabIndex = 88
        ' 
        ' txtCantidad
        ' 
        txtCantidad.Location = New Point(379, 302)
        txtCantidad.Name = "txtCantidad"
        txtCantidad.Size = New Size(254, 23)
        txtCantidad.TabIndex = 87
        ' 
        ' txtDescripcion
        ' 
        txtDescripcion.Location = New Point(379, 154)
        txtDescripcion.Name = "txtDescripcion"
        txtDescripcion.Size = New Size(254, 23)
        txtDescripcion.TabIndex = 86
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(222, 459)
        Label7.Margin = New Padding(5, 0, 5, 0)
        Label7.Name = "Label7"
        Label7.Size = New Size(141, 25)
        Label7.TabIndex = 85
        Label7.Text = "Descontinuado"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.Location = New Point(222, 357)
        Label5.Margin = New Padding(5, 0, 5, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(139, 25)
        Label5.TabIndex = 84
        Label5.Text = "Precio Unitario"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(194, 302)
        Label4.Margin = New Padding(5, 0, 5, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(169, 25)
        Label4.TabIndex = 83
        Label4.Text = "Unidad de Medida"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(242, 253)
        Label3.Margin = New Padding(5, 0, 5, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(100, 25)
        Label3.TabIndex = 82
        Label3.Text = "Proveedor"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(247, 202)
        Label2.Margin = New Padding(5, 0, 5, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(95, 25)
        Label2.TabIndex = 81
        Label2.Text = "Categoria"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(230, 162)
        Label1.Margin = New Padding(5, 0, 5, 0)
        Label1.Name = "Label1"
        Label1.Size = New Size(112, 25)
        Label1.TabIndex = 80
        Label1.Text = "Descripción"
        ' 
        ' btnCerrar
        ' 
        btnCerrar.Image = My.Resources.Resources.pngtree_vector_cross_icon_png_image_956622_removebg_preview
        btnCerrar.ImageAlign = ContentAlignment.MiddleLeft
        btnCerrar.Location = New Point(538, 521)
        btnCerrar.Name = "btnCerrar"
        btnCerrar.Size = New Size(129, 36)
        btnCerrar.TabIndex = 79
        btnCerrar.Text = "      Cancelar"
        btnCerrar.UseVisualStyleBackColor = True
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Image = My.Resources.Resources.black_check_tick_icon_4_removebg_preview1
        btnAceptar.ImageAlign = ContentAlignment.MiddleLeft
        btnAceptar.Location = New Point(247, 521)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(114, 36)
        btnAceptar.TabIndex = 78
        btnAceptar.Text = "     Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(96), CByte(125), CByte(120))
        Panel2.Controls.Add(Label10)
        Panel2.Controls.Add(Panel3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(710, 100)
        Panel2.TabIndex = 96
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label10.ForeColor = Color.Gainsboro
        Label10.Location = New Point(270, 24)
        Label10.Name = "Label10"
        Label10.Size = New Size(280, 47)
        Label10.TabIndex = 7
        Label10.Text = "Editar Producto"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(96), CByte(115), CByte(135))
        Panel3.Controls.Add(Label9)
        Panel3.Dock = DockStyle.Left
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(140, 100)
        Panel3.TabIndex = 6
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label9.ForeColor = SystemColors.ControlDark
        Label9.Location = New Point(7, 39)
        Label9.Name = "Label9"
        Label9.Size = New Size(129, 32)
        Label9.TabIndex = 17
        Label9.Text = "MED-UAM"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(96), CByte(125), CByte(139))
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 100)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(140, 482)
        Panel1.TabIndex = 97
        ' 
        ' FrmEditarProducto
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(710, 582)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        Controls.Add(txtUnidades)
        Controls.Add(Label6)
        Controls.Add(txtID)
        Controls.Add(Label8)
        Controls.Add(ChkDescontinuado)
        Controls.Add(CbCategoria)
        Controls.Add(cbProveedor)
        Controls.Add(txtPrecio)
        Controls.Add(txtCantidad)
        Controls.Add(txtDescripcion)
        Controls.Add(Label7)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnCerrar)
        Controls.Add(btnAceptar)
        Name = "FrmEditarProducto"
        Text = "FrmEditarProducto"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtUnidades As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ChkDescontinuado As CheckBox
    Friend WithEvents CbCategoria As ComboBox
    Friend WithEvents cbProveedor As ComboBox
    Friend WithEvents txtPrecio As TextBox
    Friend WithEvents txtCantidad As TextBox
    Friend WithEvents txtDescripcion As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCerrar As Button
    Friend WithEvents btnAceptar As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label10 As Label
End Class
