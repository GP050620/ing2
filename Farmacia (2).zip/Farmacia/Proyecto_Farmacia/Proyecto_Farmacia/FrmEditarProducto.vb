﻿Imports System.Data.SqlClient

Public Class FrmEditarProducto
    Private categoriaadapter As New SqlDataAdapter
    Private proveedoradapter As New SqlDataAdapter
    Private posicion As Integer
    Private posicionCB As Integer
    Dim categoriadataset As New DataSet
    Dim proveedordataset As New DataSet
    Dim Cmd_Add As SqlCommand

    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) Handles btnCerrar.Click
        CANCELAR_A_E = False
        Me.Close()
        ClearTextBoxes()
    End Sub

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
        If ConeccionBD.CONECCION.State = ConnectionState.Open Then
            ConeccionBD.Cerrar_BaseDato()
            ConeccionBD.Abrir_BaseDato()
        Else
            ConeccionBD.Abrir_BaseDato()
        End If


        If Me.txtID.Text = " " Or txtCantidad.Text = " " Or txtDescripcion.Text = " " Or txtPrecio.Text = " " Then
            MsgBox("Uno o más campos están vacios o malos. Por favor revise e intente otra vez", MsgBoxStyle.Information, "Mensaje del Sistema")
            txtID.Focus()
            Exit Sub
        End If


        ' Declaración de Variable para ver si está descontinuado o no
        Dim isChecked As Boolean = ChkDescontinuado.Checked
        Dim valueToStore As Integer = If(isChecked, 1, 0)

        If CInt(txtUnidades.Text) < 1 Then
            MsgBox("Las unidades no pueden ser menores que 1")
            Exit Sub
        End If

        Dim Insertar As String
        Dim Cmd_Add As SqlCommand
        If ConeccionBD.CONECCION.State = ConnectionState.Open Then
            ConeccionBD.Cerrar_BaseDato()
        End If

        Insertar = "UPDATE DBO.PRODUCTOS SET DES_PRODUCTO='" & (Me.txtDescripcion.Text) & "', ID_CATEGORIA='" & (Me.CbCategoria.SelectedValue) & "', ID_PROVEEDOR='" & (Me.cbProveedor.SelectedValue) & "', CANT_X_PRESENTACION='" & (Me.txtCantidad.Text) & "', PRECIO_UNIT='" & CDbl(Me.txtPrecio.Text) & "', UNIDADES_INV='" & CInt(Me.txtUnidades.Text) & "', DESCONTINUADO= '" & (valueToStore) & "'WHERE ID_PRODUCTO='" & (Me.txtID.Text) & "'"

        Try
            Call ConeccionBD.Abrir_BaseDato()
            Cmd_Add = New SqlCommand(Insertar, ConeccionBD.CONECCION)
            Cmd_Add.ExecuteNonQuery()
            MsgBox("registro guardado")
        Catch oExcep As SqlException
            MessageBox.Show("Error: " & ControlChars.CrLf & oExcep.Message & ControlChars.CrLf & oExcep.Server)
        Finally
            If ConeccionBD.CONECCION.State = ConnectionState.Open Then
                ConeccionBD.Cerrar_BaseDato()
            End If
        End Try
        CANCELAR_A_E = True
        Close()
        ClearTextBoxes()



    End Sub

    Private Sub ClearTextBoxes()
        txtCantidad.Clear()
        txtDescripcion.Clear()
        txtID.Clear()
        txtPrecio.Clear()
        ChkDescontinuado.Checked = False


    End Sub

    Private Sub FrmEditarProducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        posicion = 0
        Me.CargaDatos()
    End Sub

    Private Sub CargaDatos()

        'Declaramos variable para manipular registros con DataRow
        'Dim odatarow As DataRow
        If ConeccionBD.CONECCION.State = ConnectionState.Open Then
            ConeccionBD.Cerrar_BaseDato()
        End If
        Try
            ConeccionBD.Abrir_BaseDato()
            Dim categoriadatarow As DataRow
            Dim proveedordatarow As DataRow

            'Relacionamos los adapter con las tablas a traves de consultas Select
            Me.categoriaadapter = New SqlDataAdapter("Select * from CATEGORIAS", ConeccionBD.CONECCION)
            Me.proveedoradapter = New SqlDataAdapter("Select * from PROVEEDORES", ConeccionBD.CONECCION)

            'Limpiamos el DataSet
            categoriadataset.Clear()
            proveedordataset.Clear()

            'abrimos la conexion
            'ConeccionBD.CONECCION.Open()
            'Llenamos el DataAdapter con el metodo Fill invocando el DataSet
            Me.categoriaadapter.Fill(categoriadataset, "CATEGORIAS")
            Me.proveedoradapter.Fill(proveedordataset, "PROVEEDORES")

            'cerramos la conexion
            'ConeccionBD.CONECCION.Close()
            'establecemos que la variable odatarow va a cargar el primer registro
            posicionCB = 0
            categoriadatarow = Me.categoriadataset.Tables("CATEGORIAS").Rows(posicionCB)
            proveedordatarow = Me.proveedordataset.Tables("PROVEEDORES").Rows(posicionCB)

            'Establecemos variables para datatable y relacionamos con su respectivo DataSet
            Dim dt As DataTable = categoriadataset.Tables(0)
            Dim dt2 As DataTable = proveedordataset.Tables(0)

            'Asignamos la propiedad DisplayMember y ValueMember de los combobox
            Me.CbCategoria.DataSource = categoriadataset.Tables("CATEGORIAS")
            Me.CbCategoria.DisplayMember = "DESCATEGORIA"
            Me.CbCategoria.ValueMember = "IDCATEGORIA"
            Me.cbProveedor.DataSource = proveedordataset.Tables("PROVEEDORES")
            Me.cbProveedor.DisplayMember = "NOMBREPROVEEDOR"
            Me.cbProveedor.ValueMember = "IDPROVEEDOR"

        Finally
            If ConeccionBD.CONECCION.State = ConnectionState.Open Then
                ConeccionBD.Cerrar_BaseDato()
            End If
        End Try
    End Sub

End Class