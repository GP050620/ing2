﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtRutaSql = New TextBox()
        txtRutaCopia = New TextBox()
        CmbBasesDatos = New ComboBox()
        Label1 = New Label()
        Label2 = New Label()
        Panel3 = New Panel()
        Label3 = New Label()
        Panel1 = New Panel()
        btnBuscar = New Button()
        btnExaminar = New Button()
        btnGenerar = New Button()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' txtRutaSql
        ' 
        txtRutaSql.Location = New Point(177, 132)
        txtRutaSql.Name = "txtRutaSql"
        txtRutaSql.Size = New Size(626, 23)
        txtRutaSql.TabIndex = 0
        ' 
        ' txtRutaCopia
        ' 
        txtRutaCopia.Location = New Point(193, 184)
        txtRutaCopia.Name = "txtRutaCopia"
        txtRutaCopia.Size = New Size(332, 23)
        txtRutaCopia.TabIndex = 1
        ' 
        ' CmbBasesDatos
        ' 
        CmbBasesDatos.FormattingEnabled = True
        CmbBasesDatos.Location = New Point(643, 173)
        CmbBasesDatos.Name = "CmbBasesDatos"
        CmbBasesDatos.Size = New Size(150, 23)
        CmbBasesDatos.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(89, 135)
        Label1.Name = "Label1"
        Label1.Size = New Size(82, 15)
        Label1.TabIndex = 6
        Label1.Text = "Conexión SQL"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(89, 187)
        Label2.Name = "Label2"
        Label2.Size = New Size(98, 15)
        Label2.TabIndex = 7
        Label2.Text = "Ruta de Respaldo"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(0), CByte(150), CByte(136))
        Panel3.Controls.Add(Label3)
        Panel3.Dock = DockStyle.Top
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(902, 91)
        Panel3.TabIndex = 8
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 36F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = Color.Gainsboro
        Label3.Location = New Point(264, 9)
        Label3.Name = "Label3"
        Label3.Size = New Size(357, 65)
        Label3.TabIndex = 0
        Label3.Text = "RESPALDO SQL"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(0), CByte(150), CByte(136))
        Panel1.Dock = DockStyle.Bottom
        Panel1.Location = New Point(0, 283)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(902, 27)
        Panel1.TabIndex = 9
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Image = My.Resources.Resources.buscar_removebg_preview1
        btnBuscar.ImageAlign = ContentAlignment.MiddleLeft
        btnBuscar.Location = New Point(544, 165)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(93, 37)
        btnBuscar.TabIndex = 10
        btnBuscar.Text = "       Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' btnExaminar
        ' 
        btnExaminar.Image = My.Resources.Resources.buscar_removebg_preview1
        btnExaminar.ImageAlign = ContentAlignment.MiddleLeft
        btnExaminar.Location = New Point(424, 213)
        btnExaminar.Name = "btnExaminar"
        btnExaminar.Size = New Size(101, 37)
        btnExaminar.TabIndex = 11
        btnExaminar.Text = "          Examinar"
        btnExaminar.UseVisualStyleBackColor = True
        ' 
        ' btnGenerar
        ' 
        btnGenerar.Image = My.Resources.Resources.generar_removebg_preview
        btnGenerar.ImageAlign = ContentAlignment.MiddleLeft
        btnGenerar.Location = New Point(756, 240)
        btnGenerar.Name = "btnGenerar"
        btnGenerar.Size = New Size(134, 37)
        btnGenerar.TabIndex = 17
        btnGenerar.Text = "  Generar Repaldo"
        btnGenerar.TextAlign = ContentAlignment.MiddleRight
        btnGenerar.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(902, 310)
        Controls.Add(btnGenerar)
        Controls.Add(btnExaminar)
        Controls.Add(btnBuscar)
        Controls.Add(Panel1)
        Controls.Add(Panel3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(CmbBasesDatos)
        Controls.Add(txtRutaCopia)
        Controls.Add(txtRutaSql)
        Name = "Form1"
        Text = "Form1"
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtRutaSql As TextBox
    Friend WithEvents txtRutaCopia As TextBox
    Friend WithEvents CmbBasesDatos As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnExaminar As Button
    Friend WithEvents btnGenerar As Button
End Class
