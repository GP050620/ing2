﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Consulta_Facturas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        GroupBox1 = New GroupBox()
        btnCancelar = New Button()
        btnBuscar = New Button()
        txtNombreCliente = New TextBox()
        DataGridView1 = New DataGridView()
        btnCerrar = New Button()
        PrintDocument1 = New Printing.PrintDocument()
        Button1 = New Button()
        Panel2 = New Panel()
        Label4 = New Label()
        Panel3 = New Panel()
        Label3 = New Label()
        Panel1 = New Panel()
        btnReporte = New Button()
        GroupBox1.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(btnCancelar)
        GroupBox1.Controls.Add(btnBuscar)
        GroupBox1.Controls.Add(txtNombreCliente)
        GroupBox1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        GroupBox1.Location = New Point(180, 106)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(518, 76)
        GroupBox1.TabIndex = 0
        GroupBox1.TabStop = False
        GroupBox1.Text = "Buscar por Nombres y Apellidos de Cliente"
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Location = New Point(431, 34)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(75, 23)
        btnCancelar.TabIndex = 2
        btnCancelar.Text = "Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Location = New Point(350, 34)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(75, 23)
        btnBuscar.TabIndex = 1
        btnBuscar.Text = "Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' txtNombreCliente
        ' 
        txtNombreCliente.Location = New Point(6, 34)
        txtNombreCliente.Name = "txtNombreCliente"
        txtNombreCliente.Size = New Size(338, 23)
        txtNombreCliente.TabIndex = 0
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(180, 188)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(912, 419)
        DataGridView1.TabIndex = 1
        ' 
        ' btnCerrar
        ' 
        btnCerrar.Location = New Point(1017, 159)
        btnCerrar.Name = "btnCerrar"
        btnCerrar.Size = New Size(75, 23)
        btnCerrar.TabIndex = 3
        btnCerrar.Text = "Cerrar"
        btnCerrar.UseVisualStyleBackColor = True
        ' 
        ' PrintDocument1
        ' 
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(877, 102)
        Button1.Name = "Button1"
        Button1.Size = New Size(134, 23)
        Button1.TabIndex = 5
        Button1.Text = "Nueva Factura"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.LemonChiffon
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(Panel3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(1104, 91)
        Panel2.TabIndex = 32
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 36F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = Color.DimGray
        Label4.Location = New Point(360, 9)
        Label4.Name = "Label4"
        Label4.Size = New Size(458, 65)
        Label4.TabIndex = 7
        Label4.Text = "Facturas Tramitadas"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.PaleGoldenrod
        Panel3.Controls.Add(Label3)
        Panel3.Dock = DockStyle.Left
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(169, 91)
        Panel3.TabIndex = 5
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.ActiveCaptionText
        Label3.Location = New Point(20, 34)
        Label3.Name = "Label3"
        Label3.Size = New Size(129, 32)
        Label3.TabIndex = 18
        Label3.Text = "MED-UAM"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightGoldenrodYellow
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 91)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(169, 528)
        Panel1.TabIndex = 34
        ' 
        ' btnReporte
        ' 
        btnReporte.Image = My.Resources.Resources.generar_removebg_preview
        btnReporte.ImageAlign = ContentAlignment.MiddleLeft
        btnReporte.Location = New Point(877, 140)
        btnReporte.Name = "btnReporte"
        btnReporte.Size = New Size(134, 42)
        btnReporte.TabIndex = 35
        btnReporte.Text = "Generar Reporte"
        btnReporte.TextAlign = ContentAlignment.MiddleRight
        btnReporte.UseVisualStyleBackColor = True
        ' 
        ' Frm_Consulta_Facturas
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1104, 619)
        Controls.Add(btnReporte)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        Controls.Add(Button1)
        Controls.Add(btnCerrar)
        Controls.Add(DataGridView1)
        Controls.Add(GroupBox1)
        Name = "Frm_Consulta_Facturas"
        Text = "Frm_Consulta_Facturas"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnBuscar As Button
    Friend WithEvents txtNombreCliente As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnCerrar As Button
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnReporte As Button
End Class
