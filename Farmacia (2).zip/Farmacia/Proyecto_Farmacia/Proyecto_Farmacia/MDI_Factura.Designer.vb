﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDI_Factura
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Panel2 = New Panel()
        Button3 = New Button()
        Button2 = New Button()
        Button1 = New Button()
        btnLaboratorios = New Button()
        btnClientes = New Button()
        btnProveedores = New Button()
        btnProductos = New Button()
        btnCategorias = New Button()
        Panel3 = New Panel()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Panel1.SuspendLayout()
        Panel3.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(51), CByte(51), CByte(76))
        Panel1.Controls.Add(Panel2)
        Panel1.Controls.Add(Button3)
        Panel1.Controls.Add(Button2)
        Panel1.Controls.Add(Button1)
        Panel1.Controls.Add(btnLaboratorios)
        Panel1.Controls.Add(btnClientes)
        Panel1.Controls.Add(btnProveedores)
        Panel1.Controls.Add(btnProductos)
        Panel1.Controls.Add(btnCategorias)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(186, 540)
        Panel1.TabIndex = 2
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(51), CByte(51), CByte(65))
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(187, 91)
        Panel2.TabIndex = 3
        ' 
        ' Button3
        ' 
        Button3.FlatAppearance.BorderSize = 0
        Button3.FlatStyle = FlatStyle.Flat
        Button3.ForeColor = Color.Gainsboro
        Button3.Image = My.Resources.Resources.pngtree_backup_line_icon_vector_png_image_6656295
        Button3.ImageAlign = ContentAlignment.MiddleLeft
        Button3.Location = New Point(0, 473)
        Button3.Name = "Button3"
        Button3.Size = New Size(187, 49)
        Button3.TabIndex = 7
        Button3.Text = "Respaldo"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.FromArgb(CByte(51), CByte(51), CByte(76))
        Button2.FlatAppearance.BorderSize = 0
        Button2.FlatStyle = FlatStyle.Flat
        Button2.ForeColor = Color.Gainsboro
        Button2.Image = My.Resources.Resources.pngtree_invoice_icon_png_image_1817550_removebg_preview
        Button2.ImageAlign = ContentAlignment.MiddleLeft
        Button2.Location = New Point(0, 418)
        Button2.Name = "Button2"
        Button2.Size = New Size(187, 49)
        Button2.TabIndex = 6
        Button2.Text = "Facturas"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Button1
        ' 
        Button1.FlatAppearance.BorderSize = 0
        Button1.FlatStyle = FlatStyle.Flat
        Button1.ForeColor = Color.Gainsboro
        Button1.Image = My.Resources.Resources.line_icon_for_category_vector_removebg_preview
        Button1.ImageAlign = ContentAlignment.MiddleLeft
        Button1.Location = New Point(-1, 363)
        Button1.Name = "Button1"
        Button1.Size = New Size(187, 49)
        Button1.TabIndex = 5
        Button1.Text = "CatTipoVenta"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' btnLaboratorios
        ' 
        btnLaboratorios.FlatAppearance.BorderSize = 0
        btnLaboratorios.FlatStyle = FlatStyle.Flat
        btnLaboratorios.ForeColor = Color.Gainsboro
        btnLaboratorios.Image = My.Resources.Resources._87292946_ilustración_de_vector_de_equipo_de_laboratorio_escolar_química_tubo_de_prueba_removebg_preview
        btnLaboratorios.ImageAlign = ContentAlignment.MiddleLeft
        btnLaboratorios.Location = New Point(-1, 308)
        btnLaboratorios.Name = "btnLaboratorios"
        btnLaboratorios.Size = New Size(187, 49)
        btnLaboratorios.TabIndex = 4
        btnLaboratorios.Text = "Laboratorios"
        btnLaboratorios.UseVisualStyleBackColor = True
        ' 
        ' btnClientes
        ' 
        btnClientes.FlatAppearance.BorderSize = 0
        btnClientes.FlatStyle = FlatStyle.Flat
        btnClientes.ForeColor = Color.Gainsboro
        btnClientes.Image = My.Resources.Resources.b548eae4e34db001b7805a90ee501ca3_removebg_preview
        btnClientes.ImageAlign = ContentAlignment.MiddleLeft
        btnClientes.Location = New Point(0, 253)
        btnClientes.Name = "btnClientes"
        btnClientes.Size = New Size(187, 49)
        btnClientes.TabIndex = 3
        btnClientes.Text = "Clientes"
        btnClientes.UseVisualStyleBackColor = True
        ' 
        ' btnProveedores
        ' 
        btnProveedores.FlatAppearance.BorderSize = 0
        btnProveedores.FlatStyle = FlatStyle.Flat
        btnProveedores.ForeColor = Color.Gainsboro
        btnProveedores.Image = My.Resources.Resources._1935803
        btnProveedores.ImageAlign = ContentAlignment.MiddleLeft
        btnProveedores.Location = New Point(0, 198)
        btnProveedores.Name = "btnProveedores"
        btnProveedores.Size = New Size(187, 49)
        btnProveedores.TabIndex = 2
        btnProveedores.Text = "Proveedores"
        btnProveedores.UseVisualStyleBackColor = True
        ' 
        ' btnProductos
        ' 
        btnProductos.FlatAppearance.BorderSize = 0
        btnProductos.FlatStyle = FlatStyle.Flat
        btnProductos.ForeColor = Color.Gainsboro
        btnProductos.Image = My.Resources.Resources._1170679
        btnProductos.ImageAlign = ContentAlignment.MiddleLeft
        btnProductos.Location = New Point(-1, 91)
        btnProductos.Name = "btnProductos"
        btnProductos.Size = New Size(187, 49)
        btnProductos.TabIndex = 1
        btnProductos.Text = "Productos"
        btnProductos.UseVisualStyleBackColor = True
        ' 
        ' btnCategorias
        ' 
        btnCategorias.FlatAppearance.BorderSize = 0
        btnCategorias.FlatStyle = FlatStyle.Flat
        btnCategorias.ForeColor = Color.Gainsboro
        btnCategorias.Image = My.Resources.Resources.category_8
        btnCategorias.ImageAlign = ContentAlignment.MiddleLeft
        btnCategorias.Location = New Point(-1, 146)
        btnCategorias.Name = "btnCategorias"
        btnCategorias.Size = New Size(187, 49)
        btnCategorias.TabIndex = 0
        btnCategorias.Text = "Categorias"
        btnCategorias.UseVisualStyleBackColor = True
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(0), CByte(150), CByte(136))
        Panel3.Controls.Add(Label1)
        Panel3.Dock = DockStyle.Top
        Panel3.Location = New Point(186, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(504, 91)
        Panel3.TabIndex = 4
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 36F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = Color.Gainsboro
        Label1.Location = New Point(168, 14)
        Label1.Name = "Label1"
        Label1.Size = New Size(168, 65)
        Label1.TabIndex = 0
        Label1.Text = "HOME"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources._7502449_ai
        PictureBox1.Location = New Point(186, 89)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(506, 476)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 5
        PictureBox1.TabStop = False
        ' 
        ' MDI_Factura
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(690, 540)
        Controls.Add(PictureBox1)
        Controls.Add(Panel3)
        Controls.Add(Panel1)
        Name = "MDI_Factura"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Formulario Maestro"
        Panel1.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnCategorias As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents btnLaboratorios As Button
    Friend WithEvents btnClientes As Button
    Friend WithEvents btnProveedores As Button
    Friend WithEvents btnProductos As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
