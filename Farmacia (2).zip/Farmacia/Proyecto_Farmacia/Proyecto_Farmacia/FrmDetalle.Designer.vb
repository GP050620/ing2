﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDetalle
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtBuscar = New TextBox()
        DataGridView1 = New DataGridView()
        btnAgregar = New Button()
        txtCantidad = New TextBox()
        Label2 = New Label()
        GroupBox1 = New GroupBox()
        btnCancelar = New Button()
        btnBuscar = New Button()
        Panel2 = New Panel()
        Label4 = New Label()
        Panel3 = New Panel()
        Label3 = New Label()
        Panel1 = New Panel()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        GroupBox1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' txtBuscar
        ' 
        txtBuscar.Location = New Point(6, 30)
        txtBuscar.Name = "txtBuscar"
        txtBuscar.Size = New Size(197, 23)
        txtBuscar.TabIndex = 1
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(146, 201)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(457, 294)
        DataGridView1.TabIndex = 2
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Location = New Point(528, 549)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(75, 23)
        btnAgregar.TabIndex = 3
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' txtCantidad
        ' 
        txtCantidad.Location = New Point(503, 510)
        txtCantidad.Name = "txtCantidad"
        txtCantidad.Size = New Size(100, 23)
        txtCantidad.TabIndex = 4
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(439, 518)
        Label2.Name = "Label2"
        Label2.Size = New Size(58, 15)
        Label2.TabIndex = 5
        Label2.Text = "Cantidad:"
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(btnCancelar)
        GroupBox1.Controls.Add(btnBuscar)
        GroupBox1.Controls.Add(txtBuscar)
        GroupBox1.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point)
        GroupBox1.Location = New Point(146, 112)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(457, 83)
        GroupBox1.TabIndex = 6
        GroupBox1.TabStop = False
        GroupBox1.Text = "Buscar Medicamento"
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Image = My.Resources.Resources.pngtree_vector_cross_icon_png_image_956622_removebg_preview
        btnCancelar.ImageAlign = ContentAlignment.MiddleLeft
        btnCancelar.Location = New Point(331, 22)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(93, 37)
        btnCancelar.TabIndex = 3
        btnCancelar.Text = "        Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Image = My.Resources.Resources.buscar_removebg_preview1
        btnBuscar.ImageAlign = ContentAlignment.MiddleLeft
        btnBuscar.Location = New Point(209, 22)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(111, 37)
        btnBuscar.TabIndex = 2
        btnBuscar.Text = "      Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.LemonChiffon
        Panel2.Controls.Add(Label4)
        Panel2.Controls.Add(Panel3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(618, 100)
        Panel2.TabIndex = 31
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = Color.DimGray
        Label4.Location = New Point(199, 29)
        Label4.Name = "Label4"
        Label4.Size = New Size(371, 45)
        Label4.TabIndex = 7
        Label4.Text = "Seleccione un Producto"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.PaleGoldenrod
        Panel3.Controls.Add(Label3)
        Panel3.Dock = DockStyle.Left
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(140, 100)
        Panel3.TabIndex = 5
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = SystemColors.ActiveCaptionText
        Label3.Location = New Point(3, 39)
        Label3.Name = "Label3"
        Label3.Size = New Size(129, 32)
        Label3.TabIndex = 17
        Label3.Text = "MED-UAM"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightGoldenrodYellow
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 100)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(140, 498)
        Panel1.TabIndex = 33
        ' 
        ' FrmDetalle
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(618, 598)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        Controls.Add(GroupBox1)
        Controls.Add(Label2)
        Controls.Add(txtCantidad)
        Controls.Add(btnAgregar)
        Controls.Add(DataGridView1)
        Name = "FrmDetalle"
        Text = "FrmDetalle"
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtBuscar As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnAgregar As Button
    Friend WithEvents txtCantidad As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnBuscar As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
End Class
