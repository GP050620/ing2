﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEditarLaboratorios
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnCancelar = New Button()
        btnAceptar = New Button()
        Label7 = New Label()
        Label6 = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        txtContacto = New TextBox()
        txtFax = New TextBox()
        txtTelefono = New TextBox()
        txtDireccion = New TextBox()
        txtNombre = New TextBox()
        txtID = New TextBox()
        Label5 = New Label()
        Panel2 = New Panel()
        Panel3 = New Panel()
        Label8 = New Label()
        Panel1 = New Panel()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Image = My.Resources.Resources.pngtree_vector_cross_icon_png_image_956622_removebg_preview
        btnCancelar.ImageAlign = ContentAlignment.MiddleLeft
        btnCancelar.Location = New Point(541, 438)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(108, 36)
        btnCancelar.TabIndex = 55
        btnCancelar.Text = "      Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Image = My.Resources.Resources.black_check_tick_icon_4_removebg_preview1
        btnAceptar.ImageAlign = ContentAlignment.MiddleLeft
        btnAceptar.Location = New Point(234, 437)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(101, 36)
        btnAceptar.TabIndex = 54
        btnAceptar.Text = "     Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label7.Location = New Point(260, 263)
        Label7.Name = "Label7"
        Label7.Size = New Size(85, 25)
        Label7.TabIndex = 51
        Label7.Text = "Telefono"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label6.Location = New Point(252, 356)
        Label6.Name = "Label6"
        Label6.Size = New Size(90, 25)
        Label6.TabIndex = 50
        Label6.Text = "Contacto"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.Location = New Point(294, 305)
        Label4.Name = "Label4"
        Label4.Size = New Size(41, 25)
        Label4.TabIndex = 49
        Label4.Text = "Fax"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.Location = New Point(252, 215)
        Label3.Name = "Label3"
        Label3.Size = New Size(93, 25)
        Label3.TabIndex = 48
        Label3.Text = "Dirección"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(145, 167)
        Label2.Name = "Label2"
        Label2.Size = New Size(213, 25)
        Label2.TabIndex = 47
        Label2.Text = "Nombre de Laboratorio"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(184, 118)
        Label1.Name = "Label1"
        Label1.Size = New Size(162, 25)
        Label1.TabIndex = 46
        Label1.Text = "ID de Laboratorio"
        ' 
        ' txtContacto
        ' 
        txtContacto.Location = New Point(374, 356)
        txtContacto.Name = "txtContacto"
        txtContacto.Size = New Size(229, 23)
        txtContacto.TabIndex = 45
        ' 
        ' txtFax
        ' 
        txtFax.Location = New Point(374, 305)
        txtFax.Name = "txtFax"
        txtFax.Size = New Size(229, 23)
        txtFax.TabIndex = 44
        ' 
        ' txtTelefono
        ' 
        txtTelefono.Location = New Point(374, 263)
        txtTelefono.Name = "txtTelefono"
        txtTelefono.Size = New Size(229, 23)
        txtTelefono.TabIndex = 43
        ' 
        ' txtDireccion
        ' 
        txtDireccion.Location = New Point(374, 215)
        txtDireccion.Name = "txtDireccion"
        txtDireccion.Size = New Size(229, 23)
        txtDireccion.TabIndex = 42
        ' 
        ' txtNombre
        ' 
        txtNombre.Location = New Point(374, 167)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(229, 23)
        txtNombre.TabIndex = 41
        ' 
        ' txtID
        ' 
        txtID.Enabled = False
        txtID.Location = New Point(374, 118)
        txtID.Name = "txtID"
        txtID.ReadOnly = True
        txtID.Size = New Size(229, 23)
        txtID.TabIndex = 40
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label5.ForeColor = Color.Gainsboro
        Label5.Location = New Point(212, 24)
        Label5.Name = "Label5"
        Label5.Size = New Size(336, 47)
        Label5.TabIndex = 6
        Label5.Text = "Editar Laboratorios"
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.MediumPurple
        Panel2.Controls.Add(Panel3)
        Panel2.Controls.Add(Label5)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(655, 90)
        Panel2.TabIndex = 53
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(207), CByte(188), CByte(224))
        Panel3.Controls.Add(Label8)
        Panel3.Dock = DockStyle.Left
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(140, 90)
        Panel3.TabIndex = 7
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label8.ForeColor = SystemColors.ControlDarkDark
        Label8.Location = New Point(7, 39)
        Label8.Name = "Label8"
        Label8.Size = New Size(129, 32)
        Label8.TabIndex = 17
        Label8.Text = "MED-UAM"
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(207), CByte(188), CByte(249))
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 90)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(140, 393)
        Panel1.TabIndex = 56
        ' 
        ' FrmEditarLaboratorios
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(655, 483)
        Controls.Add(Panel1)
        Controls.Add(btnCancelar)
        Controls.Add(btnAceptar)
        Controls.Add(Panel2)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtContacto)
        Controls.Add(txtFax)
        Controls.Add(txtTelefono)
        Controls.Add(txtDireccion)
        Controls.Add(txtNombre)
        Controls.Add(txtID)
        Name = "FrmEditarLaboratorios"
        Text = "FrmEditarLaboratorios"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnAceptar As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtContacto As TextBox
    Friend WithEvents txtFax As TextBox
    Friend WithEvents txtTelefono As TextBox
    Friend WithEvents txtDireccion As TextBox
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel1 As Panel
End Class
