﻿Imports System.Data.SqlClient

Public Class FrmEditarLaboratorios
    Dim EXISTE_CATEGORIA As Boolean
    Dim EXISTE_ID As Boolean
    Dim Cmd_Add As SqlCommand
    Dim EXISTE_CONTACTO As Boolean
    Dim EXISTE_FAX As Boolean
    Dim EXISTE_NOMBRE As Boolean
    Dim EXISTE_TELEFONO As Boolean

    Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click


        If ConeccionBD.CONECCION.State = ConnectionState.Open Then
            ConeccionBD.Cerrar_BaseDato()
            ConeccionBD.Abrir_BaseDato()
        Else
            ConeccionBD.Abrir_BaseDato()
        End If


        If Me.txtID.Text = " " Or txtDireccion.Text = " " Or txtContacto.Text = " " Or txtFax.Text = " " Or txtNombre.Text = " " Or txtTelefono.Text = " " Then
            MsgBox("Uno o más campos están vacios o malos. Por favor revise e intente otra vez", MsgBoxStyle.Information, "Mensaje del Sistema")
            txtID.Focus()
            Exit Sub
        End If


        Dim Insertar As String
        Dim Cmd_Add As SqlCommand
        If ConeccionBD.CONECCION.State = ConnectionState.Open Then
            ConeccionBD.Cerrar_BaseDato()
        End If

        Insertar = "UPDATE DBO.LABORATORIOS SET NOMBRE='" & (Me.txtNombre.Text) & "', DIRECCION='" & (Me.txtDireccion.Text) & "', TELEFONO='" & (Me.txtTelefono.Text) & "', FAX='" & (Me.txtFax.Text) & "', CONTACTO='" & (Me.txtContacto.Text) & "' WHERE IDLABORATORIO='" & (Me.txtID.Text) & "'"

        Try
            Call ConeccionBD.Abrir_BaseDato()
            Cmd_Add = New SqlCommand(Insertar, ConeccionBD.CONECCION)
            Cmd_Add.ExecuteNonQuery()
            MsgBox("registro guardado")
        Catch oExcep As SqlException
            MessageBox.Show("Error: " & ControlChars.CrLf & oExcep.Message & ControlChars.CrLf & oExcep.Server)
        Finally
            If ConeccionBD.CONECCION.State = ConnectionState.Open Then
                ConeccionBD.Cerrar_BaseDato()
            End If
        End Try
        CANCELAR_A_E = True
        Close()
        ClearTextBoxes()


    End Sub

    Private Sub txtTelefono_KeyPress(sender As Object, e As KeyPressEventArgs)

        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If


        If txtTelefono.Text.Length >= 8 AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtFax_KeyPress(sender As Object, e As KeyPressEventArgs)

        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then

            e.Handled = True
        End If

        If txtFax.Text.Length >= 8 AndAlso Not Char.IsControl(e.KeyChar) Then

            e.Handled = True
        End If
    End Sub


    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        CANCELAR_A_E = False
        Me.Close()
        ClearTextBoxes()
    End Sub


    Private Sub ClearTextBoxes()
        txtDireccion.Clear()
        txtContacto.Clear()
        txtFax.Clear()
        txtID.Clear()
        txtNombre.Clear()
        txtTelefono.Clear()
    End Sub


End Class