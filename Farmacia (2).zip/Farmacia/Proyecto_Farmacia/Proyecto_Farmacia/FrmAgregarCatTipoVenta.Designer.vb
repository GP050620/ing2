﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAgregarCatTipoVenta
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel1 = New Panel()
        Panel2 = New Panel()
        Label3 = New Label()
        Panel3 = New Panel()
        Label4 = New Label()
        btnCancelar = New Button()
        btnAceptar = New Button()
        Label2 = New Label()
        Label1 = New Label()
        txtNombre = New TextBox()
        txtID = New TextBox()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.LightSlateGray
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 90)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(140, 239)
        Panel1.TabIndex = 30
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.MediumAquamarine
        Panel2.Controls.Add(Label3)
        Panel2.Controls.Add(Panel3)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(647, 90)
        Panel2.TabIndex = 31
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point)
        Label3.ForeColor = Color.Gainsboro
        Label3.Location = New Point(167, 19)
        Label3.Name = "Label3"
        Label3.Size = New Size(480, 47)
        Label3.TabIndex = 6
        Label3.Text = "Agregar Categoria de Venta"
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.SlateGray
        Panel3.Controls.Add(Label4)
        Panel3.Dock = DockStyle.Left
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(140, 90)
        Panel3.TabIndex = 5
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label4.ForeColor = SystemColors.ActiveCaptionText
        Label4.Location = New Point(6, 29)
        Label4.Name = "Label4"
        Label4.Size = New Size(129, 32)
        Label4.TabIndex = 18
        Label4.Text = "MED-UAM"
        ' 
        ' btnCancelar
        ' 
        btnCancelar.Image = My.Resources.Resources.pngtree_vector_cross_icon_png_image_956622_removebg_preview
        btnCancelar.ImageAlign = ContentAlignment.MiddleLeft
        btnCancelar.Location = New Point(477, 278)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(108, 36)
        btnCancelar.TabIndex = 29
        btnCancelar.Text = "      Cancelar"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnAceptar
        ' 
        btnAceptar.Image = My.Resources.Resources.black_check_tick_icon_4_removebg_preview1
        btnAceptar.ImageAlign = ContentAlignment.MiddleLeft
        btnAceptar.Location = New Point(167, 278)
        btnAceptar.Name = "btnAceptar"
        btnAceptar.Size = New Size(101, 36)
        btnAceptar.TabIndex = 28
        btnAceptar.Text = "     Aceptar"
        btnAceptar.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label2.Location = New Point(152, 181)
        Label2.Name = "Label2"
        Label2.Size = New Size(222, 30)
        Label2.TabIndex = 27
        Label2.Text = "Nombre de Categoría"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 15.75F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.Location = New Point(242, 109)
        Label1.Name = "Label1"
        Label1.Size = New Size(133, 30)
        Label1.TabIndex = 26
        Label1.Text = "ID Categoria"
        ' 
        ' txtNombre
        ' 
        txtNombre.Location = New Point(399, 188)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(186, 23)
        txtNombre.TabIndex = 25
        ' 
        ' txtID
        ' 
        txtID.Enabled = False
        txtID.Location = New Point(399, 118)
        txtID.Name = "txtID"
        txtID.ReadOnly = True
        txtID.Size = New Size(186, 23)
        txtID.TabIndex = 24
        ' 
        ' FrmAgregarCatTipoVenta
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(647, 329)
        Controls.Add(Panel1)
        Controls.Add(Panel2)
        Controls.Add(btnCancelar)
        Controls.Add(btnAceptar)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(txtNombre)
        Controls.Add(txtID)
        Name = "FrmAgregarCatTipoVenta"
        Text = "FrmAgregarCatTipoVenta"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnAceptar As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents Label4 As Label
End Class
