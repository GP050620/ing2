﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLaboratorios
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Panel2 = New Panel()
        TextBox1 = New TextBox()
        btnBuscar = New Button()
        btnCancelar = New Button()
        btnCargar = New Button()
        DataGridView1 = New DataGridView()
        btnNuevo = New Button()
        btnEditar = New Button()
        btnEliminar = New Button()
        PrintDocument1 = New Printing.PrintDocument()
        Panel1 = New Panel()
        Panel3 = New Panel()
        Label1 = New Label()
        Panel2.SuspendLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).BeginInit()
        Panel1.SuspendLayout()
        Panel3.SuspendLayout()
        SuspendLayout()
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.MediumPurple
        Panel2.Controls.Add(TextBox1)
        Panel2.Controls.Add(btnBuscar)
        Panel2.Controls.Add(btnCancelar)
        Panel2.Controls.Add(btnCargar)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(140, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(944, 100)
        Panel2.TabIndex = 21
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(152, 50)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(267, 23)
        TextBox1.TabIndex = 1
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Image = My.Resources.Resources.buscar_removebg_preview1
        btnBuscar.ImageAlign = ContentAlignment.MiddleLeft
        btnBuscar.Location = New Point(425, 42)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(93, 37)
        btnBuscar.TabIndex = 5
        btnBuscar.Text = "       Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' btnCancelar
        ' 
        btnCancelar.FlatAppearance.BorderSize = 0
        btnCancelar.FlatStyle = FlatStyle.Flat
        btnCancelar.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point)
        btnCancelar.ForeColor = Color.LightGray
        btnCancelar.Location = New Point(873, 3)
        btnCancelar.Name = "btnCancelar"
        btnCancelar.Size = New Size(37, 27)
        btnCancelar.TabIndex = 6
        btnCancelar.Text = "X"
        btnCancelar.UseVisualStyleBackColor = True
        ' 
        ' btnCargar
        ' 
        btnCargar.Image = My.Resources.Resources.recargar_removebg_preview
        btnCargar.ImageAlign = ContentAlignment.MiddleLeft
        btnCargar.Location = New Point(524, 42)
        btnCargar.Name = "btnCargar"
        btnCargar.Size = New Size(95, 37)
        btnCargar.TabIndex = 7
        btnCargar.Text = "Recargar"
        btnCargar.TextAlign = ContentAlignment.MiddleRight
        btnCargar.UseVisualStyleBackColor = True
        ' 
        ' DataGridView1
        ' 
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Location = New Point(146, 106)
        DataGridView1.Name = "DataGridView1"
        DataGridView1.RowTemplate.Height = 25
        DataGridView1.Size = New Size(928, 375)
        DataGridView1.TabIndex = 19
        ' 
        ' btnNuevo
        ' 
        btnNuevo.FlatAppearance.BorderSize = 0
        btnNuevo.FlatStyle = FlatStyle.Flat
        btnNuevo.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        btnNuevo.ForeColor = Color.Transparent
        btnNuevo.Image = My.Resources.Resources.nuevo_removebg_preview__1_1
        btnNuevo.ImageAlign = ContentAlignment.MiddleLeft
        btnNuevo.Location = New Point(0, 106)
        btnNuevo.Name = "btnNuevo"
        btnNuevo.Size = New Size(140, 113)
        btnNuevo.TabIndex = 2
        btnNuevo.Text = "           Nuevo"
        btnNuevo.UseVisualStyleBackColor = True
        ' 
        ' btnEditar
        ' 
        btnEditar.FlatAppearance.BorderSize = 0
        btnEditar.FlatStyle = FlatStyle.Flat
        btnEditar.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        btnEditar.ForeColor = Color.Transparent
        btnEditar.Image = My.Resources.Resources.editar_removebg_preview
        btnEditar.ImageAlign = ContentAlignment.MiddleLeft
        btnEditar.Location = New Point(0, 216)
        btnEditar.Name = "btnEditar"
        btnEditar.Size = New Size(137, 127)
        btnEditar.TabIndex = 3
        btnEditar.Text = "           Editar"
        btnEditar.UseVisualStyleBackColor = True
        ' 
        ' btnEliminar
        ' 
        btnEliminar.FlatAppearance.BorderSize = 0
        btnEliminar.FlatStyle = FlatStyle.Flat
        btnEliminar.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        btnEliminar.ForeColor = Color.Transparent
        btnEliminar.Image = My.Resources.Resources.Eliminar_removebg_preview
        btnEliminar.ImageAlign = ContentAlignment.MiddleLeft
        btnEliminar.Location = New Point(0, 341)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(137, 140)
        btnEliminar.TabIndex = 4
        btnEliminar.Text = "           Eliminar"
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(207), CByte(188), CByte(249))
        Panel1.Controls.Add(Panel3)
        Panel1.Controls.Add(btnNuevo)
        Panel1.Controls.Add(btnEditar)
        Panel1.Controls.Add(btnEliminar)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(140, 492)
        Panel1.TabIndex = 20
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(207), CByte(188), CByte(224))
        Panel3.Controls.Add(Label1)
        Panel3.Location = New Point(0, 0)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(140, 100)
        Panel3.TabIndex = 5
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point)
        Label1.ForeColor = SystemColors.ControlDarkDark
        Label1.Location = New Point(7, 39)
        Label1.Name = "Label1"
        Label1.Size = New Size(129, 32)
        Label1.TabIndex = 17
        Label1.Text = "MED-UAM"
        ' 
        ' FrmLaboratorios
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.White
        ClientSize = New Size(1084, 492)
        Controls.Add(Panel2)
        Controls.Add(DataGridView1)
        Controls.Add(Panel1)
        Name = "FrmLaboratorios"
        Text = "Laboratorios"
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(DataGridView1, ComponentModel.ISupportInitialize).EndInit()
        Panel1.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        Panel3.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel2 As Panel
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnCancelar As Button
    Friend WithEvents btnCargar As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnNuevo As Button
    Friend WithEvents btnEditar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label1 As Label
End Class
